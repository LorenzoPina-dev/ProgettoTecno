# ProgettoTecno parte java
raccoltta dati nazionali e regioneli da GitHub rielaborazione e push su altervista (csv)
